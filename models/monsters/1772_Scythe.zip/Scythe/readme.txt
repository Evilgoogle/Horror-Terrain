Scythe
By Dionesiist

Description:
La-de-la-de-la-de-da! ... =__=' stupid 30 characters.

Textures:
None

Please give me credit for my work
Do not redistribute this model without consent!

Model was uploaded 2010, June 30


Visit http://www.hiveworkshop.com for more downloads