Witch Hunter's Hat
By Dionesiist

Description:
Oh God, this is more fun than I had hoped it'd be!
This model works well with the villager models, reasonable with both the Arthas and the Paladin model (hair goes through, but it's not noticeable, I swear.), does not work with Priest, Knight, Demon Hunter or Kobold Shoveler because their head attachment point is apparently either directly on their chin or floating above their head...
EDIT: Fiddled with the positioning, just might work properly with Arthas and the Paladins now.

Textures:
None

Please give me credit for my work
Do not redistribute this model without consent!

Model was uploaded 2010, June 24
Model was last updated 2010, June 30


Visit http://www.hiveworkshop.com for more downloads